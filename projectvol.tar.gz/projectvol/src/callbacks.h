#include <gtk/gtk.h>


void
rbfon_ajouter_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
rbfon_afficher_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void 
rbfon_retour_clicked (GtkWidget *objet, gpointer user_data);



void
rbfon_modifier_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);
/*
void
on_confirmer_clicked                   (GtkWidget      *objet,
                                        gpointer         user_data);*/

void
rbfon_ajout_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data);

void
rbfon_supprimer_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
rbfon_supprr_clicked                      (GtkWidget      *objet,
                                        gpointer         user_data);

void
rbfon_modifr_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data);

void
rbfon_button4return_clicked               (GtkWidget       *button,
                                        gpointer         user_data);

void
rbfon_retour1enterid_clicked              (GtkWidget       *button,
                                        gpointer         user_data);

void
rbfon_button1gestionvol_clicked           (GtkWidget       *button,
                                        gpointer         user_data);

void
rbfon_modifyvol1_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
rbfon_buttonconfirm_clicked               (GtkWidget       *button,
                                        gpointer         user_data);

void
rbfon_buttonretour5_clicked               (GtkWidget        *button,
                                        gpointer         user_data);
/*
void
rbfon_ajouter_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
rbfon_button4return_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
rbfon_retour_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
rbfon_buttonconfirm_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
rbfon_buttonretour5_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
rbfon_ajout_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
rbfon_afficher_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
rbfon_supprimer_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
rbfon_retour1enterid_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
rbfon_supprr_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
rbfon_modifyvol1_clicked               (GtkButton       *button,
                                        gpointer         user_data);*/
