#include <gtk/gtk.h>


void
cmon_ajouter_clicked                     (GtkWidget      *objet,
                                        gpointer         user_data);

void
cmon_afficher_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
cmon_retour_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data);

void
cmon_supprimer_clicked                   (GtkWidget       *objet,
                                        gpointer         selection);

void
cmon_modifier_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);



void
cmon_button7_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
cmon_button8_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
cmon_button10_clicked                    (GtkWidget      *objet,
                                        gpointer         user_data);

void
cmon_button9_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);
/*
void
cmon_ajouter_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
cmon_afficher_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
cmon_supprimer_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
cmon_modifier_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
cmon_retour_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
cmon_button8_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
cmon_button7_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
cmon_button9_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
cmon_button10_clicked                  (GtkButton       *button,
                                        gpointer         user_data);*/

void
on_cmbutton2_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_chbutsup_clicked                    (GtkWidget       *objet,
                                        gpointer        selection);

void
on_chbutret_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);
