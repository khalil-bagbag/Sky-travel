#include <gtk/gtk.h>


void
on_button_EspaceAdmin_clicked          (GtkWidget *objet_graphique, gpointer user_data);

void
on_button_EspaceAgent_clicked          (GtkWidget *objet_graphique, gpointer user_data);

void
on_button_EspaceClient_clicked         (GtkWidget *objet_graphique, gpointer user_data);





/////////////////////// code chaima



void
chon_inscrire_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
chon_resvol_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data);

void
chon_reshotel_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
chon_logout_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data);

void
chon_buttonsupprimer_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
chon_buttonmodifier_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
chon_button1_clicked                     (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
chon_button2_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
chon_button3_clicked                     (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
chon_button4_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
chon_button5_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
chon_button6_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_chbutton8_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
chon_button7_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
chon_button9_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
chon_button10_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);



void
on_chbuttonRetour_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data);
void
on_chbafficher_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_chlogin_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

/////////////////////// code khalil
void
kbon_buttonSe_connecter_clicked          (GtkWidget *objet_graphique, gpointer user_data);

void
kbon_buttonRechercher_clicked            (GtkWidget *objet_graphique, gpointer user_data);


void
kbon_buttonPrix_clicked                  (GtkWidget *objet_graphique, gpointer user_data);

void
kbon_buttonReserver_clicked              (GtkWidget *objet_graphique, gpointer user_data);

void
kbon_buttonAfficher_clicked              (GtkWidget *objet_graphique, gpointer user_data);

void
kbon_buttonMenuReserver_clicked          (GtkWidget *objet_graphique, gpointer user_data);

void
kbon_buttonRetour_clicked                (GtkWidget *objet_graphique, gpointer user_data);

void
kbon_buttonRetourAffichageMenu_clicked   (GtkWidget *objet_graphique, gpointer user_data);

void
kbon_buttonModifier_clicked              (GtkWidget *objet_graphique, gpointer user_data);

void
kbon_buttonRetourModiferResAfficheRes_clicked (GtkWidget *objet_graphique, gpointer user_data);



void
kbon_buttonDeconnecter_clicked     (GtkWidget *objet_graphique, gpointer user_data);

void
kbon_buttonSupprimer_clicked      (GtkWidget *objet_graphique, gpointer user_data);

void
kbon_buttonConfirmer_modification_clicked (GtkWidget *objet_graphique, gpointer user_data);

void
kbon_buttonNouveauPrix_clicked    (GtkWidget *objet_graphique, gpointer user_data);

void
on_kbbutton_Retour_menu_principal_clicked (GtkWidget *objet_graphique, gpointer user_data);


/////////////////////// code agents ///////


void
on_abdoufacture_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_abdousupprimer_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_abdoumodifier_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_abdouafficher1_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_abdouprecedent_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_abdouprecedent1_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_abdouconfirmer_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_abdoumodifierr_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_abdouvalider_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_abdouafficher_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_abdou0_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data);
void
on_abdouajoute_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_abdouprecedent2_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);






void
on_abdoulogin_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_abdoudeconnecter_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_abdouretour_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_Prestation_vol_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_pres_heber_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

////////////////////code rana //////////////


void
rbfon_ajouter_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
rbfon_afficher_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void 
rbfon_retour_clicked (GtkWidget *objet, gpointer user_data);



void
rbfon_modifier_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);


void
rbfon_ajout_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data);

void
rbfon_supprimer_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
rbfon_supprr_clicked                      (GtkWidget      *objet,
                                        gpointer         user_data);

void
rbfon_modifr_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data);

void
rbfon_button4return_clicked               (GtkWidget       *button,
                                        gpointer         user_data);

void
rbfon_retour1enterid_clicked              (GtkWidget       *button,
                                        gpointer         user_data);

void
rbfon_button1gestionvol_clicked           (GtkWidget       *button,
                                        gpointer         user_data);

void
rbfon_modifyvol1_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
rbfon_buttonconfirm_clicked               (GtkWidget       *button,
                                        gpointer         user_data);

void
rbfon_buttonretour5_clicked               (GtkWidget        *button,
                                        gpointer         user_data);

void
on_rbfbutton_retour_clicked            (GtkWidget        *button,
                                        gpointer         user_data);


//////////////////////////kamel////////////////////////
void
tbon_ajouter_v_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
tbon_modifier_v_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
tbon_afficher_v_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
tbon_retour_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data);

void
tbon_button_supprimer_clicked            (GtkWidget       *objet,
                                        gpointer         selection);

void
tbon_buttonrch_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_tbbutton_retour_principal_clicked   (GtkWidget       *objet,
                                        gpointer         user_data);
 




void
on_chbutton_login1_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);
